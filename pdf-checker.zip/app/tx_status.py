import re
from pathlib import Path
from typing import List, Tuple

from pypdf import PdfReader


def _normalize_text(s: str) -> str:
    if not s:
        return ""
    s = s.casefold().replace("\u0307", "")

    tr_map = str.maketrans(
        {
            "ı": "i",
            "ö": "o",
            "ü": "u",
            "ş": "s",
            "ğ": "g",
            "ç": "c",
        }
    )
    s = s.translate(tr_map)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _extract_pdf_text(pdf_path: Path, max_pages: int = 2) -> str:
    reader = PdfReader(str(pdf_path))
    parts = []
    for page in reader.pages[:max_pages]:
        parts.append(page.extract_text() or "")
    return "\n".join(parts)


def detect_transaction_status(pdf_path: Path, max_pages: int = 2) -> str:
    """
    SAFE detector:
    - Never returns "completed" by inference.
    - Only returns completed when there is explicit wording proving completion.
    - Otherwise returns unknown.

    Returns: completed | pending | canceled | failed | unknown
    """
    try:
        raw = _extract_pdf_text(pdf_path, max_pages=max_pages)
    except Exception:
        return "unknown"

    t = _normalize_text(raw)

    RULES: List[Tuple[str, List[str]]] = [
        ("canceled", [
            r"\biptal\b",
            r"\biptal edildi\b",
            r"\bcanceled\b",
            r"\bcancelled\b",
            r"\bcancel\b",
            r"\bgeri alindi\b",
            r"\bgeri cekildi\b",
        ]),
        ("failed", [
            r"\bbasarisiz\b",
            r"\bhata\b",
            r"\breddedildi\b",
            r"\bfailed\b",
            r"\brejected\b",
            r"\bunsuccessful\b",
        ]),
        ("pending", [
            r"\bbeklemede\b",
            r"\bonay bekliyor\b",
            r"\bonayda\b",
            r"\baskida\b",
            r"\bisleniyor\b",
            r"\bisleme alindi\b",
            r"\bpending\b",
            r"\bprocessing\b",
            r"\bawaiting\b",
        ]),
        # Completed only when explicitly stated OR phrased as "money was taken/sent".
        ("completed", [
            r"\btamamlandi\b",
            r"\bgerceklesti\b",
            r"\bbasarili\b",
            r"\bcompleted\b",
            r"\bsuccess\b",
            r"\bsuccessful\b",

            # Strong Turkish receipt phrases that imply finalization:
            r"\bhesabinizdan\b.*\bcekilmistir\b",   # PTT-style: "Hesabınızdan ... çekilmiştir"
            r"\btransfer\b.*\bgerceklesti\b",
            r"\btransfer\b.*\btamamlandi\b",
        ]),
    ]

    for status, pats in RULES:
        for pat in pats:
            if re.search(pat, t):
                return status

    return "unknown"
