from .parser import parse_garanti
