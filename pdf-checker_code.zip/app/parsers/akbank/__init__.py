from .parser import parse_akbank
