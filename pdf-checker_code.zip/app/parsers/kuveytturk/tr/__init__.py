# kuveytturk turkish variant
