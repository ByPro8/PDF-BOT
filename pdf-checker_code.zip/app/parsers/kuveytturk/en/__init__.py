# kuveytturk english variant
