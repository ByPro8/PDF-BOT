import re
from pathlib import Path
from typing import Dict, Optional

from pypdf import PdfReader


def _extract_text(pdf_path: Path, max_pages: int = 2) -> str:
    reader = PdfReader(str(pdf_path))
    parts = []
    for page in reader.pages[:max_pages]:
        parts.append(page.extract_text() or "")
    return "\n".join(parts)


def _norm(s: str) -> str:
    if not s:
        return ""
    s = s.casefold().replace("\u0307", "")  # dotted-i combining mark
    tr = str.maketrans({"ı": "i", "ö": "o", "ü": "u", "ş": "s", "ğ": "g", "ç": "c"})
    s = s.translate(tr)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _clean_one_line(v: Optional[str]) -> Optional[str]:
    if not v:
        return None
    # keep only the first physical line (prevents "TR"/"BSMV" bleeding in)
    v = v.splitlines()[0].strip()
    v = re.sub(r"\s+", " ", v).strip()

    # drop trailing junk tokens banks sometimes put on next line
    toks = v.split()
    while toks and toks[-1].upper() in {"TR", "BSMV", "TL", "TRY"}:
        toks.pop()
    v = " ".join(toks).strip()

    return v or None


def _find_line_after_label(raw: str, labels: list[str]) -> Optional[str]:
    # label on its own line:
    # Label\nVALUE
    for lab in labels:
        m = re.search(rf"(?:^|\n)\s*{re.escape(lab)}\s*\n\s*([^\n]+)", raw, flags=re.I)
        if m:
            return _clean_one_line(m.group(1))
    return None


def _find_inline_after_label(raw: str, labels: list[str]) -> Optional[str]:
    # label:value on same line (or label  value)
    for lab in labels:
        m = re.search(rf"{re.escape(lab)}\s*[:\-]?\s*([^\n]+)", raw, flags=re.I)
        if m:
            return _clean_one_line(m.group(1))
    return None


def _find_iban(raw: str) -> Optional[str]:
    m = re.search(r"\bTR\s*(?:\d\s*){24}\b", raw, flags=re.I)
    if not m:
        return None
    return re.sub(r"\s+", " ", m.group(0)).upper().strip()


def _find_amount(raw: str) -> Optional[str]:
    # EN: Amount\n75,538.00 TRY
    # TR: Tutar\n50.000,00 TL
    m = re.search(
        r"(?:^|\n)\s*(?:Amount|Tutar)\s*\n\s*([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{2})?)\s*(TRY|TL)\b",
        raw,
        flags=re.I,
    )
    if m:
        return f"{m.group(1)} {m.group(2).upper()}"

    # fallback: any amount-looking token
    m2 = re.search(r"\b([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{2})?)\s*(TRY|TL)\b", raw, flags=re.I)
    if m2:
        return f"{m2.group(1)} {m2.group(2).upper()}"

    return None


def _find_time(raw: str) -> Optional[str]:
    # EN templates can be: "TransactionDate" or "Transaction Date"
    # Sometimes value is on the next line, sometimes same line with ":".
    v = _find_line_after_label(
        raw,
        [
            "TransactionDate",
            "Transaction Date",
            "Transaction Date:",
            "İşlem Tarihi",
            "Islem Tarihi",
        ],
    )

    if not v:
        # label + value on same line
        m = re.search(
            r"(?:TransactionDate|Transaction\s*Date|İşlem\s*Tarihi|Islem\s*Tarihi)\s*[:\n ]+\s*([0-9]{2}[./][0-9]{2}[./][0-9]{4}\s+[0-9]{2}:[0-9]{2})",
            raw,
            flags=re.I,
        )
        if m:
            v = m.group(1)
        else:
            # last-resort fallback: first date+time in the document
            m2 = re.search(r"\b([0-9]{2}[./][0-9]{2}[./][0-9]{4})\s+([0-9]{2}:[0-9]{2})\b", raw)
            if not m2:
                return None
            v = f"{m2.group(1)} {m2.group(2)}"

    v2 = v.replace("/", ".").strip()
    m = re.search(r"\b(\d{2}\.\d{2}\.\d{4})\s+(\d{2}:\d{2})\b", v2)
    if m:
        return f"{m.group(1)} {m.group(2)}"

    return v2


def _find_receipt(raw: str) -> Optional[str]:
    v = _find_line_after_label(raw, ["Query Number", "Sorgu Numarası", "Sorgu Numarasi"])
    if v:
        m = re.search(r"\b(\d{6,})\b", v)
        return m.group(1) if m else v

    # fallback: inline
    v2 = _find_inline_after_label(raw, ["Query Number", "Sorgu Numarası", "Sorgu Numarasi"])
    if v2:
        m = re.search(r"\b(\d{6,})\b", v2)
        return m.group(1) if m else v2

    return None


def _find_ref(raw: str) -> Optional[str]:
    # Many KuveytTurk PDFs vary spelling/spacing.
    # IMPORTANT: ignore label-fragments like "erance" (no digits).
    def pick_ref_token(txt: str) -> Optional[str]:
        if not txt:
            return None

        # Prefer tokens that contain at least one digit (real refs do).
        m = re.search(r"\b(?=[A-Z0-9-]*\d)[A-Z0-9]{3,}(?:-[A-Z0-9]+)*\b", txt, flags=re.I)
        if m:
            return m.group(0)

        # Sometimes refs are purely numeric
        m2 = re.search(r"\b\d{8,}\b", txt)
        if m2:
            return m2.group(0)

        return None

    v = _find_line_after_label(
        raw,
        [
            "TransactionReferance",
            "TransactionReference",
            "Transaction Reference",
            "Transaction Ref",
            "İşlem Referansı",
            "Islem Referansi",
        ],
    )

    if not v:
        v = _find_inline_after_label(
            raw,
            [
                "TransactionReferance",
                "TransactionReference",
                "Transaction Reference",
                "Transaction Ref",
                "İşlem Referansı",
                "Islem Referansi",
            ],
        )

    # If we captured "erance" or other junk (no digits), ignore it.
    tok = pick_ref_token(v or "")
    if tok:
        return tok

    # Fallback 1: common ref style like "ACYBD-B-202601"
    m3 = re.search(r"\b(?=[A-Z0-9-]*\d)[A-Z0-9]{3,}-[A-Z0-9]+-\d{6}\b", raw, flags=re.I)
    if m3:
        return m3.group(0)

    # Fallback 2: any digit-containing ref-like token
    m4 = re.search(r"\b(?=[A-Z0-9-]*\d)[A-Z0-9]{6,}(?:-[A-Z0-9]+)*\b", raw, flags=re.I)
    if m4:
        return m4.group(0)

    return None


def _detect_status_kuveytturk(raw: str) -> str:
    t = _norm(raw)

    if re.search(r"\biptal\b|\biade\b|\bbasarisiz\b|\breddedildi\b|\bcancel", t):
        return "canceled"

    if re.search(r"\bbeklemede\b|\bisleniyor\b|\bonay bekliyor\b|\bpending\b|\bprocessing\b", t):
        return "pending"

    if "isleminiz gerceklestirilmistir" in t or "transaction completed" in t or "successfully completed" in t:
        return "completed"

    return "unknown — PDF does not state status; check manually"


def _is_en_template(raw: str) -> bool:
    t = _norm(raw)
    # strong EN signals seen in your EN receipts
    return ("transaction details" in t) or ("sender name" in t) or ("transactiondate" in t) or ("amount" in t)


def _find_sender_en(raw: str) -> Optional[str]:
    v = _find_line_after_label(raw, ["Sender Name"])
    if not v:
        v = _find_inline_after_label(raw, ["Sender Name"])
    return _clean_one_line(v)


def _find_receiver_en(raw: str) -> Optional[str]:
    v = _find_line_after_label(raw, ["Recipient", "Recipient Name", "Beneficiary", "Receiver"])
    if not v:
        v = _find_inline_after_label(raw, ["Recipient", "Recipient Name", "Beneficiary", "Receiver"])
    return _clean_one_line(v)


def _find_sender_tr(raw: str) -> Optional[str]:
    # Try explicit labels first (rare in TR incoming)
    v = _find_line_after_label(raw, ["Gönderen", "Gonderen", "Gönderici", "Gonderici"])
    if not v:
        m = re.search(r"(?:^|\n)\s*(?:Gönderen|Gonderen|Gönderici|Gonderici)\s*[: ]\s*([^\n]+)", raw, flags=re.I)
        if m:
            v = m.group(1)
    v = _clean_one_line(v)

    # Fallback: if PDF has two "Müşteri Adı" blocks, 2nd is usually the counterparty (sender)
    if not v:
        names = re.findall(r"(?:^|\n)\s*Müşteri Adı\s+([^\n]+)", raw, flags=re.I)
        names = [_clean_one_line(x) for x in names if _clean_one_line(x)]
        if len(names) >= 2:
            v = names[1]

    return v


def _find_receiver_tr(raw: str) -> Optional[str]:
    # Common: "Gönderilen Faruk Can Yaman"
    m = re.search(r"(?:^|\n)\s*(?:Gönderilen|Gonderilen)\s*[: ]?\s*([^\n]+)", raw, flags=re.I)
    if m:
        return _clean_one_line(m.group(1))

    v = _find_line_after_label(raw, ["Alıcı", "Alici", "Gönderilen", "Gonderilen"])
    if not v:
        v = _find_inline_after_label(raw, ["Alıcı", "Alici", "Gönderilen", "Gonderilen"])
    v = _clean_one_line(v)

    # Fallback: first "Müşteri Adı" is usually the KuveytTurk account owner (receiver)
    if not v:
        names = re.findall(r"(?:^|\n)\s*Müşteri Adı\s+([^\n]+)", raw, flags=re.I)
        names = [_clean_one_line(x) for x in names if _clean_one_line(x)]
        if names:
            v = names[0]

    return v


def parse_kuveytturk(pdf_path: Path) -> Dict:
    raw = _extract_text(pdf_path, 2)

    if _is_en_template(raw):
        sender = _find_sender_en(raw)
        receiver = _find_receiver_en(raw)
    else:
        sender = _find_sender_tr(raw)
        receiver = _find_receiver_tr(raw)

    iban = _find_iban(raw)
    amount = _find_amount(raw)
    time = _find_time(raw)
    receipt = _find_receipt(raw)
    ref = _find_ref(raw)

    status = _detect_status_kuveytturk(raw)

    return {
        "tr_status": status,
        "sender_name": sender,
        "receiver_name": receiver,
        "receiver_iban": iban,
        "amount": amount,
        "transaction_time": time,
        "receipt_no": receipt,
        "transaction_ref": ref,
    }
