import re
from pathlib import Path
from typing import Dict, Optional

from app.parsers.kuveytturk._shared import (
    _extract_text,
    _find_iban,
    _find_amount,
    _find_time,
    _find_receipt,
    _find_ref,
    _detect_status_kuveytturk,
    _norm,
)


def _clean_name(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\s+", " ", s)
    # remove common stray tokens that sometimes appear on next line or appended
    s = re.sub(r"\s+(?:TR|BSMV|KATILIMCI)$", "", s, flags=re.I).strip()
    return s


def _next_nonempty(lines, i: int) -> Optional[str]:
    j = i + 1
    while j < len(lines) and not lines[j].strip():
        j += 1
    return lines[j].strip() if j < len(lines) else None


def _find_receiver_tr(lines) -> Optional[str]:
    # TR template: "Gönderilen" then next line is recipient name
    for i, ln in enumerate(lines):
        if _norm(ln) in ("gonderilen", "gönderilen"):
            v = _next_nonempty(lines, i)
            if v:
                return _clean_name(v)
    return None


def _find_sender_tr(lines, receiver_name: Optional[str]) -> Optional[str]:
    # Some TR templates: "Gönderen" then next line
    for i, ln in enumerate(lines):
        if _norm(ln) in ("gonderen", "gönderen"):
            v = _next_nonempty(lines, i)
            if v:
                return _clean_name(v)

    # Your KuveytTurk incoming template shows TWO "Müşteri Adı" blocks.
    # One is receiver, the other is sender.
    names = []
    for i, ln in enumerate(lines):
        if _norm(ln) in ("musteri adi", "müşteri adı"):
            v = _next_nonempty(lines, i)
            if v:
                names.append(_clean_name(v))

    # remove empties + obvious junk
    names = [n for n in names if n and n.lower() not in ("tr", "bsmv", "katilimci")]

    if not names:
        return None

    if receiver_name:
        r = _norm(receiver_name)
        for n in names:
            if _norm(n) != r:
                return n

    # fallback: if 2 names exist and receiver missing, assume 1st receiver 2nd sender
    if len(names) >= 2:
        return names[-1]

    return names[0]


def parse_kuveyt_turk_tr(pdf_path: Path) -> Dict:
    raw = _extract_text(pdf_path, 2)
    lines = [l.strip() for l in raw.splitlines() if l.strip()]

    receiver = _find_receiver_tr(lines)
    sender = _find_sender_tr(lines, receiver)

    iban = _find_iban(raw)
    amount = _find_amount(raw)
    time = _find_time(raw)
    receipt = _find_receipt(raw)
    ref = _find_ref(raw)

    status = _detect_status_kuveytturk(raw)

    return {
        "tr_status": status,
        "sender_name": sender,
        "receiver_name": receiver,
        "receiver_iban": iban,
        "amount": amount,
        "transaction_time": time,
        "receipt_no": receipt,
        "transaction_ref": ref,
    }
