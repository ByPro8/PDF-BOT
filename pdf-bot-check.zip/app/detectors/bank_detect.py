import re
from pathlib import Path
from typing import Callable, Optional

from pypdf import PdfReader

# Optional OCR fallback: keep import inside function so it doesn't break deployments
# if pytesseract isn't installed.


def extract_text(pdf_path: Path, max_pages: int = 2) -> str:
    reader = PdfReader(str(pdf_path))
    parts = []
    for page in reader.pages[:max_pages]:
        parts.append(page.extract_text() or "")
    return "\n".join(parts)


def normalize_text(text: str) -> str:
    # normalize + simplify Turkish chars
    t = (text or "").casefold()
    tr = str.maketrans({"ı": "i", "ö": "o", "ü": "u", "ş": "s", "ğ": "g", "ç": "c"})
    t = t.translate(tr)
    t = re.sub(r"\s+", " ", t)
    return t.strip()


# ----------------------------
# Bank detectors (bool)
# ----------------------------

def is_pttbank(text: str) -> bool:
    t = text
    return ("pttbank" in t) or ("ptt bank" in t)


def is_qnb(text: str) -> bool:
    t = normalize_text(text)

    # QNB templates can show "QNB Bank A.Ş." and/or the website.
    # Do NOT require the word "finansbank" (new templates may omit it).
    return (
        ("qnb.com.tr" in t)
        or ("www.qnb.com.tr" in t)
        or ("qnb bank" in t)
        or ("qnb bank a.s" in t)
        or ("qnb bank a.ş" in t)
        or ("qnb finansbank" in t)
        or ("finansbank" in t)
    )



def is_halkbank(text: str) -> bool:
    t = text
    return ("halkbank" in t) or ("halk bankasi" in t)


def is_tombank(text: str) -> bool:
    t = text
    return ("tom bank" in t) or ("tombank" in t)


def is_isbank(text: str) -> bool:
    t = text
    return ("turkiye is bankasi" in t) or ("isbank" in t) or ("is bankasi" in t)


def is_turkiye_finans(text: str) -> bool:
    t = text
    return ("turkiye finans" in t) or ("turkiyefinans" in t)


def is_ing(text: str) -> bool:
    t = text
    return ("ing" in t) and ("ing bank" in t or "ingbank" in t or "ing mobil" in t)


def is_kuveyt_turk(text: str) -> bool:
    # fallback only: domain present
    return "kuveytturk.com.tr" in text


# --- KuveytTurk variants ---
# text is already normalized by normalize_text()

def is_kuveyt_turk_en(text: str) -> bool:
    """
    EN variant (English template).
    Requires:
    - kuveytturk.com.tr
    AND at least one strong English signal.
    """
    t = text.casefold()
    return ("kuveytturk.com.tr" in t) and (
        ("kuveyt turk participation bank" in t)
        or ("money transfer to iban" in t)
        or ("outgoing" in t)
        or ("transactiondate" in t)
        or ("query number" in t)
    )


def is_kuveyt_turk_tr(text: str) -> bool:
    """
    TR variant (Turkish template).
    Requires:
    - kuveytturk.com.tr
    AND at least one strong Turkish signal.
    """
    t = text.casefold()
    return ("kuveytturk.com.tr" in t) and (
        ("kuveyt turk katilim bankasi" in t)
        or ("iban'a para transferi" in t)
        or ("mobil sube" in t)
        or ("aciklama" in t)
        or ("sorgu numarasi" in t)
        or ("islem tarihi" in t)
    )


Detector = tuple[str, str, Optional[str], Callable[[str], bool]]

# IMPORTANT:
# - Put more specific templates BEFORE generic ones.
DETECTORS: list[Detector] = [
    ("PTTBANK", "PttBank", None, is_pttbank),
    ("QNB", "QNB", None, is_qnb),
    ("HALKBANK", "Halkbank", None, is_halkbank),
    ("TOMBANK", "TOM Bank", None, is_tombank),
    ("ISBANK", "Isbank", None, is_isbank),
    ("TURKIYE_FINANS", "TurkiyeFinans", None, is_turkiye_finans),
    ("ING", "ING", None, is_ing),

    # KuveytTurk variants first
    ("KUVEYT_TURK_EN", "KuveytTurk", "EN", is_kuveyt_turk_en),
    ("KUVEYT_TURK_TR", "KuveytTurk", "TR", is_kuveyt_turk_tr),
    # fallback if domain exists but we can't classify
    ("KUVEYT_TURK", "KuveytTurk", "UNKNOWN", is_kuveyt_turk),
]


def _ocr_text(pdf_path: Path) -> str:
    # optional OCR fallback (only if you enabled it)
    try:
        from pdf2image import convert_from_path
        import pytesseract
    except Exception:
        return ""

    images = convert_from_path(str(pdf_path), first_page=1, last_page=1)
    if not images:
        return ""
    return pytesseract.image_to_string(images[0]) or ""


def detect_bank_variant(pdf_path: Path, use_ocr_fallback: bool = False) -> dict:
    raw = extract_text(pdf_path, max_pages=2)
    text = normalize_text(raw)

    method = "text"
    if not text and use_ocr_fallback:
        raw2 = _ocr_text(pdf_path)
        text = normalize_text(raw2)
        method = "ocr" if text else "none"

    for key, bank_name, variant, pred in DETECTORS:
        try:
            if pred(text):
                return {"key": key, "bank": bank_name, "variant": variant, "method": method}
        except Exception:
            continue

    return {"key": "UNKNOWN", "bank": "Unknown", "variant": None, "method": method}
